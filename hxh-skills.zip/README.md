# Claude Code Skills — Nen / NeoForge 1.21.1

Pacote de skills para ser colocado diretamente na raiz do repositório.

Estrutura:

```text
.claude/
└── skills/
    ├── neoforge-1-21-1/
    │   └── SKILL.md
    ├── nen-lore-rules/
    │   └── SKILL.md
    ├── nen-architecture/
    │   └── SKILL.md
    ├── git-workflow/
    │   └── SKILL.md
    ├── code-review/
    │   └── SKILL.md
    └── testing/
        └── SKILL.md
```

## Como instalar no projeto

Copie a pasta `.claude` para a raiz do repositório e faça commit dela.

```bash
git add .claude
git commit -m "chore: add shared Claude Code skills"
git push
```

O Claude Code detecta skills de projeto em `.claude/skills/<nome>/SKILL.md`. O nome da pasta pode ser usado como comando, por exemplo:

```text
/nen-lore-rules
/nen-architecture
/neoforge-1-21-1
/code-review
/testing
/git-workflow
```

As descriptions também permitem carregamento automático quando o Claude considerar a skill relevante.

## Papel de cada skill

- **nen-lore-rules**: fonte de verdade de regras de Nen e base para futuras mecânicas.
- **nen-architecture**: traduz o lore para uma arquitetura extensível de código.
- **neoforge-1-21-1**: evita uso de APIs antigas/novas incompatíveis e define regras técnicas de NeoForge.
- **git-workflow**: fluxo seguro para duas pessoas e múltiplas sessões do Claude trabalharem em paralelo.
- **code-review**: checklist de revisão com foco em servidor, persistência, segurança, performance e consistência de Nen.
- **testing**: estratégia de testes unitários, GameTests, dedicated server e multiplayer.

## Fontes principais usadas

### Claude Code

- https://code.claude.com/docs/pt/skills
- https://code.claude.com/docs/pt/claude-directory
- https://code.claude.com/docs/pt/best-practices

### NeoForge 1.21.1

- https://docs.neoforged.net/docs/1.21.1/gettingstarted/
- https://docs.neoforged.net/docs/1.21.1/concepts/events/
- https://docs.neoforged.net/docs/1.21.1/datastorage/attachments/
- https://docs.neoforged.net/docs/1.21.1/datastorage/saveddata/
- https://docs.neoforged.net/docs/1.21.1/items/datacomponents/
- https://docs.neoforged.net/docs/1.21.1/networking/payload/
- https://docs.neoforged.net/docs/1.21.1/misc/gametest/

### Nen / Hunter x Hunter

- https://hunterxhunter.fandom.com/wiki/Nen
- https://hunterxhunter.fandom.com/wiki/Chapter_60
- https://hunterxhunter.fandom.com/wiki/Exhibition:_Togashi_Yoshihiro_-Puzzle-

A Hunterpedia foi usada como índice de pesquisa e resumo de capítulos. Para decisões delicadas de cânone, a recomendação dentro da própria skill é conferir o mangá/material oficial publicado e marcar incertezas em vez de transformar interpretação de fã em regra rígida.
